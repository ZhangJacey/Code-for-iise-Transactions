%_________________________________________________________________________%
%  
% Hybrid Whale Optimization Algorithm 
% with Simulated Annealing for Feature Selection 
%           By: Majdi Mafarja and Seyedali Mirjalili   
%           email: mmafarjeh@gmail.com
% 
% Main paper: M. Mafarja and S. Mirjalili                                 %
%               Hybrid Whale Optimization Algorithm                       %
%               with Simulated Annealing for Feature Selection            %
%               Neurocomputing , in press,                                %
%               DOI: https://doi.org/10.1016/j.neucom.2017.04.053         %
%                                                                         %
%  Developed in MATLAB R2014a                                             %
%                                                                         %
%  the original code of WOA is availble on                                %
%                                                                         %
%       Homepage: http://www.alimirjalili.com                             %
%                e-Mail: ali.mirjalili@gmail.com                          %
%                      
%_________________________________________________________________________%

function y =AccSz(x)
%we used this function to calculate the fitness value as in the paper 
global A trn vald 
weight = [1,4,2,2,5,6,2,5,2,5,4,1,1,2,2,5]/-sum([1,4,2,2,5,6,2,5,2,5,4,1,1,2,2,5]);
SzW=0.1;
 x1=x>0.5;
 x1=cat(2,x1,zeros(size(x1,1),1));  % ��x�ͣ�x, 1������������ƴ��
 x1=logical(x1);

if sum(x1)==0
    y=inf;
    return;
end
c = knnclassify(A(vald,x1),A(trn,x1),A(trn,end));  % A(trn,end)��ʾA��trn�е����һ��
cp = classperf(A(vald,end),c);  % ������������������
% mdl = fitcknn(A(trn,x1),A(trn,end),'NumNeighbors');%kΪ��Ӧ��1,2,3,4.....
% c = predict(mdl,A(vald,x1));
% cp = classperf(A(vald,end),c);  % ������������������
% y=(1-SzW)*(1-cp.CorrectRate)+SzW*sum(x)/(length(x)-1);  % sum(x)����ѡ�Ӽ�����������
% y=(1-SzW)*(1-(cp.Sensitivity * cp.Specificity)^(1/2))+SzW*sum(x)/(length(x)-1);  % sum(x)����ѡ�Ӽ�����������
% y=(1-SzW-0.1)*(1-(cp.Sensitivity * cp.Specificity)^(1/2))+SzW*sum(x1)/(length(x1)-1)+0.1.* (weight*x.');  % sum(x)����ѡ�Ӽ�����������
% disp('cp.Sensitivity')
% disp(cp.Sensitivity)
% disp('cp.Specificity')
% disp(cp.Specificity)
y=1-(cp.Sensitivity * cp.Specificity)^(1/2);
% y=1-cp.CorrectRate;