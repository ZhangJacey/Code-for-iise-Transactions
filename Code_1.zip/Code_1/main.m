%_________________________________________________________________________%
%  
% Hybrid Whale Optimization Algorithm 
% with Simulated Annealing for Feature Selection 
%           By: Majdi Mafarja and Seyedali Mirjalili   
%           email: mmafarjeh@gmail.com
% 
% Main paper: M. Mafarja and S. Mirjalili                                 %
%               Hybrid Whale Optimization Algorithm                       %
%               with Simulated Annealing for Feature Selection            %
%               Neurocomputing , in press,                                %
%               DOI: https://doi.org/10.1016/j.neucom.2017.04.053         %
%                                                                         %
%  Developed in MATLAB R2014a                                             %
%                                                                         %
%  the original code of WOA is availble on                                %
%                                                                         %
%       Homepage: http://www.alimirjalili.com                             %
%                e-Mail: ali.mirjalili@gmail.com                          %
%                      
%_________________________________________________________________________%
close all;clearvars;clc;warning off;
clc
global A trn vald a;
SearchAgents_no=5; % Number of search agents
Max_iteration=100; % Maximum numbef of iterations  ��MaxIter������������������

% A=load('zoo2.dat');
% A=load('breastcancer1.dat');
% A=load('SPECT31.dat');
% A=load('SPECTF32.dat');
% A=load('housevotes4.dat');
A=load('lymphography5.dat');
disp('AA')
disp(A)
disp('AA')
sumScore = 0;
minScore = 1;
maxScore = 0;
% target_1=zeros(1,5);
% target_2=zeros(1,5);
% target_3=zeros(1,5);
% pos=[];
tic % �������浱ǰʱ��
% for i = 1:5
r=randperm(size(A,1));   % ��1-A�и������������������
trn=r(1:4*floor(length(r)/5));  % trn���ڴ��ҵ�������н�ȡǰһ�����
vald=r(4*floor(length(r)/5)+1:end);  % vald���ڴ��ҵ�������н�ȡ��һ�����

[Best_score,Best_pos,WOA_cg_curve,fName]=WOASA(SearchAgents_no,(Max_iteration),0,1,size(A,2)-1,'AccSz');
% acc = Acc1(Best_pos(1,:));
    % fprintf('Acc  %f\tFitness:  %f\tSolution:  %s\tDimention: %d\tTime:  %f\n',acc,Best_score,num2str(Best_pos,'%1d'),sum(Best_pos(:)),time);
    % disp(['Acc:', acc,'Best_score:',Best_score,'Best_pos:', Best_pos, 'Numbers_of_characteristics:',sum(Best_pos(:)), 'Time:', time])
%     target_1(i)=Best_score(1,1);
%     target_2(i)=Best_score(1,2);
%     target_3(i)=Best_score(1,3);
%     pos=[pos;Best_pos];
% end
time = toc;  % ��¼�������ʱ��

% disp(mean(target_1))
% disp(var(target_1))
% disp(mean(target_2))
% disp(var(target_2))
% disp(mean(target_3))
% disp(var(target_3))
% disp(pos)

%     disp(acc)
disp(Best_score)
disp(Best_pos)
disp(sum(Best_pos,2))
disp(time)
for i = 1:size(Best_pos,1)
    disp(Acc1(Best_pos(i,:)))
end