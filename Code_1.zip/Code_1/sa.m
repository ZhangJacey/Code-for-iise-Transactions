%
% Copyright (c) 2015, Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "license.txt" for license terms.
%
% Project Code: YPEA106
% Project Title: Real-Coded Simulated Annealing in MATLAB
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: S. Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
function BestSol = sa(sol,dim, Max_iter)
%% Problem Definition
global A trn vald acc a;

%% SA Parameters

MaxIt=30;     % Maximum Number of Iterations

MaxSubIt=10;    % Maximum Number of Sub-iterations

% T0=10;       % Initial Temp.
% T0=2*dim; 
T0=0.1;
alpha=0.98;     % Temp. Reduction Rate
%% Initialization
% fitness = feval('AccSz',sol)+feval('fitness2',Sol)+feval('fitness3',Sol);
fitness = feval('AccSz',sol);
BestSol = sol;
BestCost = fitness;
currentSol = sol;
currentCost = fitness;

% Array to Hold Best Cost Values
BestCostMat=zeros(MaxIt,1);
% Intialize Temp.
T=T0;

%% SA Main Loop
    for it=1:MaxIt
    % it=1;
    % while T>0.1
    %     fprintf('%d ',it);
        for subit=1:MaxSubIt
            % Create and Evaluate New Solution
            % newSol = MutationU(dim,Max_iter,currentSol,subit);
            newSol = MutationU(dim,MaxIt,currentSol,it);
            % Evaluation
            % newCost=feval('AccSz',newSol)+feval('fitness2',newSol)+feval('fitness3',newSol);
            newCost=feval('AccSz',newSol);
            % replace the best and the current solution if the new solution is better 
%             disp([newCost,currentCost])
            if newCost < currentCost %&& sum(newSol(:)) < sum(currentSol(:))
%                 disp('���1')
                currentSol=newSol;
                currentCost = newCost;
                BestSol=currentSol;
                BestCost = newCost;
            elseif (newCost == currentCost)
                if (feval('fitness2',newSol) < feval('fitness2',currentSol))
%                     disp('�������222111')
                    currentSol=newSol;
                    currentCost = newCost;
                    BestSol=currentSol;
                    BestCost = newCost;
                end
            else % Accepting a worst solution
%                  disp('���3')
                 DELTA=(newCost-currentCost)/currentCost;
                 % DELTA=(newCost-currentCost);
                 P=exp(-DELTA/T);
                 
                 if rand<=P
%                      disp(['p' P])
%                      disp('���1111113')
                     currentSol=newSol;
                     currentCost = newCost;
                 end
             end   

        end
        % Store Best Cost Ever Found
        % BestCostMat(it)=BestCost;
        % it = it+1;
        % Display Iteration Information
    %      disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCostMat(it))]);
        % Update Temp.
        T=alpha*T ;   
    end
disp('                BestCost                  :')
disp(BestCost)
%% Results

% figure;
% %plot(BestCost,'LineWidth',2);
% semilogy(BestCostMat,'LineWidth',2);
% xlabel('Iteration');
% ylabel('Best Cost');
% grid on;
end