function pt= testlittle(S1,t,Max_iter)
n_row = size(S1,1);
norm_r = sqrt(sum(abs(S1).^2,2)); % same as norm(S1,2,'rows')
S2 = zeros(n_row,n_row);
for i = 1:n_row
  for j = i:n_row
    S2(i,j) = dot(S1(i,:), S1(j,:)) / (norm_r(i) * norm_r(j));
    S2(j,i) = S2(i,j);
  end
end
[a,b]=size(S2);
num = a*b-n_row;
disp('(sum(S2(:))- n_row)/num')
disp((sum(S2(:))- n_row)/num)
disp('t/Max_iter')
disp(t/Max_iter)
disp('-30*(max(sum(S2(:)- n_row)/2,t/Max_iter))')
disp(-30*(max((sum(S2(:))- n_row)/num,t/Max_iter)))
% pt = exp(-30*(min((sum(S2(:))- n_row)/num,t/Max_iter)))+0.2;
cos = (sum(S2(:))- n_row)/num;
pt = exp(-5*(t/Max_iter)^(cos))+0.25;

disp('cos')
disp(cos)
% pdist(S1,'cosine')
% S2 = squareform(1-pdist(S1,'cosine')) + eye(size(S1,1));
