clear;clc;
pop_num = 50;
i_max = 200;
pc = 1;
pm = 0.1;
eta1 = 20;
eta2 = 20;
v = 30;
min_range = zeros(1,v);
max_range = ones(1,v);
 
 
func = @ZDT1;
pop = initialize_variables(pop_num,min_range,max_range);
best_fitness = [];
best_pop = [];
fitness = compute_fitness(pop,func);
rank = non_domination_sort(fitness);
chromo = crowding_distance(rank,fitness);
for i = 1:i_max
    tour = 2;
    parent_pop = tournament_selection(pop,fitness,tour);
    offspring_pop = cross_mutation(parent_pop,func,pc,pm,min_range,max_range,eta1,eta2);
    pop = elitism(parent_pop,offspring_pop,func);
    fitness = compute_fitness(pop,func);
    rank = non_domination_sort(fitness);
    chromo = crowding_distance(rank,fitness);
end
plot(fitness(:,1),fitness(:,2),'*');